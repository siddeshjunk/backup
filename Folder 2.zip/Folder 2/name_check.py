# -*- coding: utf-8 -*-
"""
Created on Thu Apr 12 12:25:05 2018

@author: Siddesh.S
"""

name1 = input("Enter name 1: ")
name2 = input("Enter name 2: ")
len(name1)
len(name2)
if len(name1) == len(name2):
    if name1 == name2:
        print ("The names are the same")
    else:
        print ("The names are different, but are the same length. Here: '%s' '%s'" % (name1, name2))
if len(name1) > len(name2):
    print ("%s is longer than %s" % (name1, name2))
        #print ("%d is longer than %d" % (len(name1), len(name2)))
elif len(name1) < len(name2):
  print ("%s is longer than %s" % (name2, name1))
  
site = ['xerox', 'lawyer meet', "agreement", 
             'money']
print(site[1])
calls = ['hemanth', 'niti']
to_do = [site, calls]
to_do[0][2]
