import pandas as pd
import numpy as np
import matplotlib.pyplot as plt 
import seaborn as sns



df1=pd.read_excel(r'D:\interview.xlsx', sheetname='Customer Profile Data (DS#1)')
df2=pd.read_excel(r'D:\interview.xlsx', sheetname='Past Purchase Data (Ds#2)')
df3=pd.read_excel(r'D:\interview.xlsx', sheetname='Campaign Coverage Data (DS#3)')
df4=pd.read_excel(r'D:\interview.xlsx', sheetname='Month Level Customer Data (DS#4')
df5=pd.read_excel(r'D:\interview.xlsx', sheetname='Socio Economic Data (DS#5)')


# In[41]:


df6=pd.merge(df1,df2,how='left',on='Customer_ID')
df6=pd.merge(df6,df3,how='left',on='Customer_ID')
df6=pd.merge(df6,df5,how='left',on='Customer_ID')

df6['education']=np.where(df6['education'] =='basic.9y', 'Basic', df6['education'])
df6['education']=np.where(df6['education'] =='basic.6y', 'Basic', df6['education'])
df6['education']=np.where(df6['education'] =='basic.4y', 'Basic', df6['education'])

droplist=['marital_status',
       'Previous_Default_Flag', 'House_Owned_Flag',
       'Income_USD', 'Credit_rating', 'Ethnicity', 'Loyalty_Tier', 'Mode_of_contact',
       'month_last_contacted_x', 'day_of_week_last_contacted',
       'duration_last_contact', 'num_of_contact_campaign',
       'days_elapsed_last_contact', 'buy_decision_flag', 'Campaign_Start_Date',
       'Duration_of_last_contact_type',
       'month_last_contacted_y', 'Qtrly_Emp_variation_rate',
       ' Monthly_consumer_price_idx', 'Monthly_consumer_conf_idx',
       'US_FED_3mnth_rate', 'Quarterly_num_of_emp']

df7=df6.drop(columns=droplist,axis=1)

df7_1 = pd.get_dummies(df7['job'],drop_first=True)
df7_2 = pd.get_dummies(df7['education'],drop_first=True)
df7_3 = pd.get_dummies(df7['Loan_Availed_Flag'],drop_first=True)
df7_4 = pd.get_dummies(df7['Life_Stage_Code'],drop_first=True)
df7_5 = pd.get_dummies(df7['Employment'],drop_first=True)
df7_6 = pd.get_dummies(df7['outcome_last_campaign'],drop_first=True)
df7_7 = pd.get_dummies(df7['Num_of_contact_campaign_type'],drop_first=True)
df7_8 = pd.get_dummies(df7['Num_contact_before_campaign_type'],drop_first=True)


droplist2 = ['Avg_Basket_Size','Reward_Points_Earned','job','education','Loan_Availed_Flag','Life_Stage_Code','Employment','outcome_last_campaign','Num_of_contact_campaign_type','Num_contact_before_campaign_type']
df7=df7.drop(columns=droplist2,axis=1)

df7 = pd.concat([df7,df7_1,df7_2,df7_3,df7_4,df7_5,df7_6,df7_7,df7_8],axis=1)
df7

df7.to_csv(r'D:\interview2.csv', index = None, header=True) 

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(df7.drop('Target_buy',axis=1),df7['Target_buy'], test_size=0.30,random_state=101)

from sklearn.linear_model import LogisticRegression
logmodel = LogisticRegression()
logmodel.fit(X_train,y_train)
predictions = logmodel.predict(X_test)

from sklearn.metrics import classification_report,accuracy_score
print(classification_report(y_test,predictions))
print("Accuracy:",accuracy_score(y_test, predictions))


from sklearn.metrics import confusion_matrix
print(confusion_matrix(y_test, predictions))

