import urllib.request

response=urllib.request.urlopen('http://www.pythonchallenge.com/pc/def/linkedlist.php')
print(response.read())
