# -*- coding: utf-8 -*-
"""
Created on Thu Apr 11 18:08:01 2019

@author: Siddesh.S
"""

str_="g fmnc wms bgblr rpylqjyrc gr zw fylb. rfyrq ufyr amknsrcpq ypc dmp. bmgle gr gl zw fylb gq glcddgagclr ylb rfyr'q ufw rfgq rcvr gq qm jmle. sqgle qrpgle.kyicrpylq() gq pcamkkclbcb. lmu ynnjw ml rfc spj."
decoded_str=' '
for i in str_:
    int_=ord(i)
    int_=int_+2
    decoded_str+chr(int_)
    print()

print(decoded_str)