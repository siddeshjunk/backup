import numpy as np
import cv2
import os

'''
This script generates heatmap for a single input video.
'''

# loop through the below code to generate heatmap for multiple camera sources
os.chdir('C:\\Users\\siddesh.s\\Desktop\\Video_Projects\\Project heatmap\\menswear')

cap = cv2.VideoCapture('menswear.mp4')

bg_remover = cv2.bgsegm.createBackgroundSubtractorMOG()

first_iter = True

while cap.isOpened():
    #save the first frame in memory after applying the color map
    if first_iter:
        ret, frame = cap.read()
        cv2.imwrite('original_color.jpg', frame)
        first_frame = frame.copy() #copying to add the the color_image to first_frame
        #created output images to check relevant colormap
        first_frame_winter = cv2.applyColorMap(first_frame, cv2.COLORMAP_WINTER)
        first_frame_jet = cv2.applyColorMap(first_frame, cv2.COLORMAP_JET)
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        cv2.imwrite('original_gray.jpg', gray)
        height, width = gray.shape
        # need accum_image to add all threshold images
        accum_image = np.zeros((height, width), np.uint8)
        first_iter = False
    # second frame onwards falls to else block
    else:
        ret, frame = cap.read()
        try:
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)# convert to grayscale
        except:
            # even when the video ends, cap.isOpened returns True. Not sure why
            # workaround as of now.
            break

        fgmask = bg_remover.apply(gray)  # remove the background

        # for testing
        cv2.imshow('Background Removed', fgmask)

        # applying thresh to extract movement; increase max_value for more movement detection
        ret, thresh = cv2.threshold(fgmask, 2, 2, cv2.THRESH_BINARY)

        # add to the accumulated image
        accum_image = cv2.add(accum_image, thresh)

    # for testing purposes, show the current frame
    cv2.imshow('Orginal', frame)
    cv2.imshow('accumulated image',accum_image)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        # please press 'q' to end the program mid-run
        break

# apply a color map, PINK works too
color_image = cv2.applyColorMap(accum_image, cv2.COLORMAP_HOT)

# overlay the color mapped image to the first frame
result_overlay_winter = cv2.addWeighted(first_frame_winter, 0.7, color_image, 0.7, 0)
result_overlay_jet = cv2.addWeighted(first_frame_jet, 0.7, color_image, 0.7, 0)

# save the final overlay image
cv2.imwrite('overlayed_heatmap_winter.jpg', result_overlay_winter)
cv2.imwrite('overlayed_heatmap_jet.jpg', result_overlay_jet)
cv2.imwrite('heatmap.jpg', color_image)

#closing all open frames
cap.release()
cv2.destroyAllWindows()
