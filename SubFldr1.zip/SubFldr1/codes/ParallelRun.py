# -*- coding: utf-8 -*-
"""
Created on Tue Jul  9 10:09:49 2019

@author: Abhipsa.Dash
"""


import threading
from multiprocessing import Process

def Function1():
    import Script1
    Script1.main()
    
    
def Function2():
    import Script2
    Script2.main()
 
    
# creating thread for parallel processing
t1 = threading.Thread(target=Function1) 
t2 = threading.Thread(target=Function2) 

  
# starting thread 1 
t1.start()
#Starting thread 2
t2.start() 

  
# wait until thread 1 is completely executed 
t1.join()
# wait until thread 2 is completely executed 
t2.join() 


  
print("Done!") 



